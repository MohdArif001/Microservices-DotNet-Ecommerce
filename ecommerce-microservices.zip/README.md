# .NET 8 Microservices E-Commerce Starter

This project includes:
- Catalog, Basket, Order Microservices
- Identity Service with JWT Auth
- SQL Server via Docker
- API Gateway using YARP
